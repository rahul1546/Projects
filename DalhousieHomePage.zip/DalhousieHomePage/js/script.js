function getFeedback(){
let feedback = window.prompt("What feedback/suggestions do you have for our website?");
if(feedback!=null){
    console.log(feedback)
}

}
