<!--- The following README.md sample file was adapted from https://gist.github.com/PurpleBooth/109311bb0361f32d87a2#file-readme-template-md by Raghav Sampangi for academic use --->  

# Group Lab 4 (GL4) in CSCI 1170 (Winter 2022)

Date Created: 11/03/2022
Last Modification Date: 12/03/2022

## Author(s)

- Full Name: <Rahul Kumar>
- Email: rh747577@dal.ca

## Citations/Attributions

1. Include citations in this format: Author/Website URL, Content used from the source, Year published (if available), and Date accessed.

https://www.dal.ca/,  Images for banner and other sections as well, 12/03/2022

https://cdn.dal.ca/_jcr_content/contentPar/featureslider/featureSlider/homepageslide_527129128/image.adaptive.1280.high.jpg/1645619183919.jpg-->,banner.jpg"
https://cdn.dal.ca/admissions/future-students/_jcr_content/contentPar/staticimage.adaptive.full.high.jpg/1636047506203.jpg-->1636047506203.jpg
Image used:https://www.vmcdn.ca/f/files/halifaxtoday/images/education/101317-dalhousie-sign-mg.jpg--> dalhousie-01.jpg"
https://cdn.dal.ca/about-dal/_jcr_content/contentPar/staticimage.adaptive.full.high.jpg/1630799659575.jpg-->img/1630799659575.jpg
<!--image used https://cdn.dal.ca/about-dal/dal-and-the-community/_jcr_content/contentPar/staticimage.adaptive.full.high.jpg/1595860610907.jpg-->
			img/1595860610907.jpg"
all logos has been taken from dalhousie website
submit linkis at the bottom